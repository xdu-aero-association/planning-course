#!/bin/bash

# run ros node
source devel/setup.bash
rviz


