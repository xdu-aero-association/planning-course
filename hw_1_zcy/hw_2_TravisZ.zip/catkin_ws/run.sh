#!/bin/bash

# run ros node
source devel/setup.bash
roslaunch grid_path_searcher demo.launch


