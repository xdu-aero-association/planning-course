#!/bin/bash

# build ros workspace
catkin_make -DCMAKE_EXPORT_COMPILE_COMMANDS=Yes


