#include <hw_tool.h>

using namespace std;
using namespace Eigen;

float *roots_quadratic_equation(float a, float b, float c)
{
    //the first element is the number of the real roots, and other elements are the real roots.
    float *roots = new float[3];
    if (a == 0.0)
    {
        if (b == 0.0)
        {
            roots[0] = 0.0;
        }
        else
        {
            roots[1] = -c / b;
            roots[0] = 1.0;
        }
    }
    else
    {
        float d = b * b - 4 * a * c;
        if (d < 0.0)
        {
            roots[0] = 0.0;
        }
        else
        {
            roots[1] = (-b + sqrt(d)) / (2 * a);
            roots[2] = (-b - sqrt(d)) / (2 * a);
            roots[0] = 2.0;
        }
    }
    return roots;
}

float *roots_cubic_equation(float a, float b, float c, float d)
{
    //the first element is the number of the real roots, and other elements are the real roots.
    //Shengjin's formula
    float *roots = new float[4];
    if (a == 0)
    {
        roots = roots_quadratic_equation(b, c, d);
    }
    else
    {
        float A = b * b - 3 * a * c;
        float B = b * c - 9 * a * d;
        float C = c * c - 3 * b * d;
        float deita = B * B - 4 * A * C;

        if ((A == B) && (A == 0))
        {
            //the three roots are the same
            if (a != 0)
            {
                roots[1] = -b / (3 * a);
            }
            else
            {
                if (b != 0)
                {
                    roots[1] = -c / b;
                }
                else
                {
                    if (c != 0)
                    {
                        roots[1] = -3 * d / c;
                    }
                }
            }
            roots[2] = roots[1];
            roots[3] = roots[1];
            roots[0] = 3;
        }
        else if (deita > 0)
        {
            //only one real root
            float y1 = A * b + (3 * a / 2) * (-B + sqrt(deita));
            float y2 = A * b + (3 * a / 2) * (-B - sqrt(deita));
            float pow_y1, pow_y2;
            if (y1 < 0)
            {
                //for pow(a,b), when b is not int, a should not be negative.
                pow_y1 = -pow(-y1, 1.0 / 3.0);
            }
            else
            {
                pow_y1 = pow(y1, 1.0 / 3.0);
            }
            if (y2 < 0)
            {
                pow_y2 = -pow(-y2, 1.0 / 3.0);
            }
            else
            {
                pow_y2 = pow(y2, 1.0 / 3.0);
            }
            roots[1] = (-b - pow_y1 - pow_y2) / (3 * a);
            roots[0] = 1;
        }
        else if (deita == 0)
        {
            //three real roots and two of them are the same
            float K = B / A;
            roots[1] = -b / a + K;
            roots[2] = -K / 2;
            roots[3] = -K / 2;
            roots[0] = 3;
        }
        else if (deita < 0)
        {
            //three different real roots
            float theta = acos((2 * A * b - 3 * a * B) / (2 * pow(A, 1.5)));
            roots[1] = (-b - 2 * sqrt(A) * cos(theta / 3)) / (3 * a);
            roots[2] = (-b + sqrt(A) * (cos(theta / 3) + sqrt(3) * sin(theta / 3))) / (3 * a);
            roots[3] = (-b + sqrt(A) * (cos(theta / 3) - sqrt(3) * sin(theta / 3))) / (3 * a);
            roots[0] = 3;
        }
    }
    return roots;
}

float *roots_quartic_equation(float a, float b, float c, float d, float e)
{
    //the first element is the number of the real roots, and other elements are the real roots.
    //Ferrari's solution.
    float *roots = new float[5];
    if (a == 0)
    {
        roots = roots_cubic_equation(b, c, d, e);
    }
    else
    {
        float b1 = b / a;
        float c1 = c / a;
        float d1 = d / a;
        float e1 = e / a;
        if ((b1 == 0) && (c1 == 0) && (d1 == 0))
        {
            //in this special case, such as a=1, b=c=d=0, e=-1, the roots should be +1 and -1
            if (e1 > 0)
            {
                roots[0] = 0.0;
            }
            else
            {
                roots[1] = sqrt(sqrt(-e1));
                roots[2] = -sqrt(sqrt(-e1));
                roots[0] = 2.0;
            }
        }
        else
        {
            float *roots_y = new float[4];
            roots_y = roots_cubic_equation(-1.0, c1, 4 * e1 - b1 * d1, d1 * d1 + e1 * b1 * b1 - 4 * e1 * c1);
            float y = roots_y[1];
            float B1, B2, C1, C2;
            if (b1 * b1 - 4 * c1 + 4 * y == 0)
            {
                B1 = b / 2;
                B2 = b / 2;
                C1 = y / 2;
                C2 = y / 2;
            }
            else
            {
                B1 = b / 2 - sqrt(b1 * b1 - 4 * c1 + 4 * y) / 2;
                B2 = b / 2 + sqrt(b1 * b1 - 4 * c1 + 4 * y) / 2;
                C1 = y / 2 - (b1 * y - 2 * d1) / (2 * sqrt(b1 * b1 - 4 * c1 + 4 * y));
                C2 = y / 2 + (b1 * y - 2 * d1) / (2 * sqrt(b1 * b1 - 4 * c1 + 4 * y));
            }
            float *roots_x1 = new float[3];
            float *roots_x2 = new float[3];
            roots_x1 = roots_quadratic_equation(1.0, B1, C1);
            roots_x2 = roots_quadratic_equation(1.0, B2, C2);
            if (roots_x1[0] != 0)
            {
                for (int i = 1; i < roots_x1[0] + 1; i++)
                {
                    roots[i] = roots_x1[i];
                }
            }
            if (roots_x2[0] != 0)
            {
                int roots_x1_number = int(roots_x1[0]);
                for (int j = 1; j < roots_x2[0] + 1; j++)
                {
                    roots[roots_x1_number + j] = roots_x2[j];
                }
            }
            roots[0] = roots_x1[0] + roots_x2[0];
        }
    }
    return roots;
}

void Homeworktool::initGridMap(double _resolution, Vector3d global_xyz_l, Vector3d global_xyz_u, int max_x_id, int max_y_id, int max_z_id)
{
    gl_xl = global_xyz_l(0);
    gl_yl = global_xyz_l(1);
    gl_zl = global_xyz_l(2);

    gl_xu = global_xyz_u(0);
    gl_yu = global_xyz_u(1);
    gl_zu = global_xyz_u(2);

    GLX_SIZE = max_x_id;
    GLY_SIZE = max_y_id;
    GLZ_SIZE = max_z_id;
    GLYZ_SIZE = GLY_SIZE * GLZ_SIZE;
    GLXYZ_SIZE = GLX_SIZE * GLYZ_SIZE;

    resolution = _resolution;
    inv_resolution = 1.0 / _resolution;

    data = new uint8_t[GLXYZ_SIZE];
    memset(data, 0, GLXYZ_SIZE * sizeof(uint8_t));
}

void Homeworktool::setObs(const double coord_x, const double coord_y, const double coord_z)
{
    if (coord_x < gl_xl || coord_y < gl_yl || coord_z < gl_zl ||
        coord_x >= gl_xu || coord_y >= gl_yu || coord_z >= gl_zu)
        return;

    int idx_x = static_cast<int>((coord_x - gl_xl) * inv_resolution);
    int idx_y = static_cast<int>((coord_y - gl_yl) * inv_resolution);
    int idx_z = static_cast<int>((coord_z - gl_zl) * inv_resolution);

    data[idx_x * GLYZ_SIZE + idx_y * GLZ_SIZE + idx_z] = 1;
}

bool Homeworktool::isObsFree(const double coord_x, const double coord_y, const double coord_z)
{
    Vector3d pt;
    Vector3i idx;

    pt(0) = coord_x;
    pt(1) = coord_y;
    pt(2) = coord_z;
    idx = coord2gridIndex(pt);

    int idx_x = idx(0);
    int idx_y = idx(1);
    int idx_z = idx(2);

    return (idx_x >= 0 && idx_x < GLX_SIZE && idx_y >= 0 && idx_y < GLY_SIZE && idx_z >= 0 && idx_z < GLZ_SIZE &&
            (data[idx_x * GLYZ_SIZE + idx_y * GLZ_SIZE + idx_z] < 1));
}

Vector3d Homeworktool::gridIndex2coord(const Vector3i &index)
{
    Vector3d pt;

    pt(0) = ((double)index(0) + 0.5) * resolution + gl_xl;
    pt(1) = ((double)index(1) + 0.5) * resolution + gl_yl;
    pt(2) = ((double)index(2) + 0.5) * resolution + gl_zl;

    return pt;
}

Vector3i Homeworktool::coord2gridIndex(const Vector3d &pt)
{
    Vector3i idx;
    idx << min(max(int((pt(0) - gl_xl) * inv_resolution), 0), GLX_SIZE - 1),
        min(max(int((pt(1) - gl_yl) * inv_resolution), 0), GLY_SIZE - 1),
        min(max(int((pt(2) - gl_zl) * inv_resolution), 0), GLZ_SIZE - 1);

    return idx;
}

Eigen::Vector3d Homeworktool::coordRounding(const Eigen::Vector3d &coord)
{
    return gridIndex2coord(coord2gridIndex(coord));
}

double Homeworktool::OptimalBVP(Eigen::Vector3d _start_position, Eigen::Vector3d _start_velocity, Eigen::Vector3d _target_position)
{
    double optimal_cost = 10000000; // this just to initial the optimal_cost, you can delete it
                                    /*
                    



    STEP 2: go to the hw_tool.cpp and finish the function Homeworktool::OptimalBVP
    the solving process has been given in the document

    because the final point of trajectory is the start point of OBVP, so we input the pos,vel to the OBVP

    after finish Homeworktool::OptimalBVP, the Trajctory_Cost will record the optimal cost of this trajectory


    */

    double px0 = _start_position(0);
    double py0 = _start_position(1);
    double pz0 = _start_position(2);
    double vx0 = _start_velocity(0);
    double vy0 = _start_velocity(1);
    double vz0 = _start_velocity(2);
    double px1 = _target_position(0);
    double py1 = _target_position(1);
    double pz1 = _target_position(2);
    double vx1 = 0;
    double vy1 = 0;
    double vz1 = 0;
    // x
    double cx1 = -36 * std::pow(px1 - px0, 2);
    double cx2 = 72 * (px1 - px0) * vx0;
    double cx3 = -36 * std::pow(vx0, 2);
    double cx4 = 24 * (px1 - px0) * (vx1 - 2 * vx0);
    double cx5 = -24 * vx0 * (vx1 - 2 * vx0);
    double cx6 = -4 * (vx1 * vx1 - 5 * vx1 * vx0 + 4 * vx0 * vx0);

    //y
    double cy1 = -36 * std::pow(py1 - py0, 2);
    double cy2 = 72 * (py1 - py0) * vy0;
    double cy3 = -36 * std::pow(vy0, 2);
    double cy4 = 24 * (py1 - py0) * (vy1 - 2 * vy0);
    double cy5 = -24 * vy0 * (vy1 - 2 * vy0);
    double cy6 = -4 * (vy1 * vy1 - 5 * vy1 * vy0 + 4 * vy0 * vy0);

    //z

    double cz1 = -36 * std::pow(pz1 - pz0, 2);
    double cz2 = 72 * (pz1 - pz0) * vz0;
    double cz3 = -36 * std::pow(vz0, 2);
    double cz4 = 24 * (pz1 - pz0) * (vz1 - 2 * vz0);
    double cz5 = -24 * vz0 * (vz1 - 2 * vz0);
    double cz6 = -4 * (vz1 * vz1 - 5 * vz1 * vz0 + 4 * vz0 * vz0);

    //

    double d1 = cx1 + cy1 + cz1;
    double d2 = cx2 + cy2 + cz2 + cx4 + cy4 + cz4;
    double d3 = cx3 + cy3 + cz3 + cx5 + cy5 + cz5 + cx6 + cy6 + cz6;

    float *roots = roots_quartic_equation(d1, d2, d3, 0, 1);
    double root = 0.000001;
    vector<double> root_vector;

    if (roots[0] > 2.5)
    {
        if (roots[1] > 0.00001)
        {
            root = roots[1];
            root_vector.push_back(root);
        }
        if (roots[2] > 0.00001)
        {
            root = roots[2];
            root_vector.push_back(root);
        }
        if (roots[3] > 0.00001)
        {
            root = roots[3];
            root_vector.push_back(root);
        }
    }
    else if (roots[0] > 1.5)
    {

        if (roots[1] > 0.00001)
        {
            root = roots[1];
            root_vector.push_back(root);
        }
        if (roots[2] > 0.00001)
        {
            root = roots[2];
            root_vector.push_back(root);
        }
    }
    else if (roots[0] > 0.5)
    {
        if (roots[1] > 0.00001)
        {
            root = roots[1];
            root_vector.push_back(root);
        }
    }

    optimal_cost = 1e7;
    for (auto t : root_vector)
    {
        double cost;
        root = 1 / t;
        ROS_INFO("find root  %f", root);
        double a1 = -12 * (px1 - root * vx0 - px0) / std::pow(root, 3) - 6 * (vx1 - vx0) / std::pow(root, 2);
        double b1 = 6 * (px1 - root * vx0 - px0) / std::pow(root, 2) - 2 * (vx1 - vx0) / root;

        double a2 = -12 * (py1 - root * vy0 - py0) / std::pow(root, 3) - 6 * (vy1 - vy0) / std::pow(root, 2);
        double b2 = 6 * (py1 - root * vy0 - py0) / std::pow(root, 2) - 2 * (vy1 - vy0) / root;

        double a3 = -12 * (pz1 - root * vz0 - pz0) / std::pow(root, 3) - 6 * (vz1 - vz0) / std::pow(root, 2);
        double b3 = 6 * (pz1 - root * vz0 - pz0) / std::pow(root, 2) - 2 * (vz1 - vz0) / root;

        cost = root + 0.33 * std::pow(root, 3) * (a1 * a1 + a2 * a2 + a3 * a3) + std::pow(root, 2) * (a1 * b1 + a2 * b2 + a3 * b3) + root * (b1 * b1 + b2 * b2 + b3 * b3);
        ROS_INFO("cost  %f", cost);
        if (cost < optimal_cost)
        {
            optimal_cost = cost;
        }
    }

    ROS_INFO("optimal_cost  %f", optimal_cost);
    return optimal_cost;
}
